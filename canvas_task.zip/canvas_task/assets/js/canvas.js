const TOTAL_PARTITION = 3;

var ctx;
var canvas;

var img;
var pieces;
var wholeWidth;
var wholeHeight;
var pieceWidth;
var pieceHeight;
var _currentPiece;
var _currentDropPiece;  

var mousePointer;

var canvasObj 	=	{
	init 	:	function(){
	    img 		=	new Image(500, 500);
	    img.addEventListener('load', canvasObj.onImage, false);
	    img.src 	=	"../assets/images/1.jpg";
	},

	onImage 	:	function(e){
	    pieceWidth		=	Math.floor(img.width / TOTAL_PARTITION)
	    pieceHeight		=	Math.floor(img.height / TOTAL_PARTITION)
	    wholeWidth 		= 	pieceWidth * TOTAL_PARTITION;
	    wholeHeight 	=	pieceHeight * TOTAL_PARTITION;

	    initPuzzle();
	}
};

function initPuzzle(){
	canvas			=	document.getElementById('content');
	ctx 			= 	canvas.getContext('2d');
	canvas.width 	= 	wholeWidth;
    canvas.height 	= 	wholeHeight;
    pieces 			= 	[];
    mousePointer 	= 	{x:0,y:0};

    ctx.drawImage(img, 0, 0, wholeWidth, wholeHeight, 0, 0, wholeWidth, wholeHeight);
    ctx.fillStyle 	= 	"#FFFFFF";
    ctx.textAlign 	= 	"center";
    ctx.font 		= 	"20px Arial";
    ctx.fillText("Click on the image to Kick off", 250, 470);

    buildPieces();
}

function buildPieces(){
    var i;
    var piece;
    var xPos 		= 	0;
    var yPos 		= 	0;
    var totalpiece	=	TOTAL_PARTITION * TOTAL_PARTITION;

    for(i = 0;i < totalpiece;i++){
        piece 		= 	{};
        piece.sx 	= 	xPos;
        piece.sy 	= 	yPos;

        pieces.push(piece);
        xPos 	+= 	pieceWidth;

        if(xPos >= wholeWidth){
            xPos	= 	0;
            yPos 	+= 	pieceHeight;
        }
    }

    document.onmousedown = shufflePuzzle;
}

function shufflePuzzle(){
    pieces 	= 	shuffle(pieces);

    ctx.clearRect(0,0,wholeWidth,wholeHeight);

    var i;
    var piece;
    var xPos 	= 	0;
    var yPos 	= 	0;
    for(i = 0;i < pieces.length;i++){
        piece 		= 	pieces[i];
        piece.xPos 	=	xPos;
        piece.yPos 	= 	yPos;

        ctx.drawImage(img, piece.sx, piece.sy, pieceWidth, pieceHeight, xPos, yPos, pieceWidth, pieceHeight);
        ctx.strokeRect(xPos, yPos, pieceWidth,pieceHeight);

        xPos += pieceWidth;

        if(xPos >= wholeWidth){
            xPos 	= 	0;
            yPos 	+= 	pieceHeight;
        }
    }
    document.onmousedown 	= 	onPuzzleClick;
}

function onPuzzleClick(e){
	console.log(e);
    if(e.layerX || e.layerX == 0){
        mousePointer.x 	= 	e.layerX - canvas.offsetLeft;
        mousePointer.y 	= 	e.layerY - canvas.offsetTop;
    }
    else if(e.offsetX || e.offsetX == 0){
        mousePointer.x 	= 	e.offsetX - canvas.offsetLeft;
        mousePointer.y 	= 	e.offsetY - canvas.offsetTop;
    }

    _currentPiece = checkClickedPiece();

    if(_currentPiece != null){
        ctx.clearRect(_currentPiece.xPos,_currentPiece.yPos,pieceWidth,pieceHeight);
        ctx.save();

        ctx.globalAlpha 	= 	.9;

        ctx.drawImage(img, _currentPiece.sx, _currentPiece.sy, pieceWidth, pieceHeight, mousePointer.x - (pieceWidth / 2), mousePointer.y - (pieceHeight / 2), pieceWidth, pieceHeight);
        ctx.restore();

        document.onmousemove 	= 	updatePuzzle;
        document.onmouseup 		= 	pieceDropped;
    }
}

function checkClickedPiece(){
    var i;
    var piece;

    for(i = 0;i < pieces.length;i++){
        piece 	= 	pieces[i];
        if(mousePointer.x < piece.xPos || mousePointer.x > (piece.xPos + pieceWidth) || mousePointer.y < piece.yPos || 
        mousePointer.y > (piece.yPos + pieceHeight)){}
        else{
            return piece;
        }
    }
    return null;
}

function updatePuzzle(e){
    _currentDropPiece 	= 	null;

    if(e.layerX || e.layerX == 0){
        mousePointer.x 	= 	e.layerX - canvas.offsetLeft;
        mousePointer.y 	= 	e.layerY - canvas.offsetTop;
    }
    else if(e.offsetX || e.offsetX == 0){
        mousePointer.x 	= 	e.offsetX - canvas.offsetLeft;
        mousePointer.y 	= 	e.offsetY - canvas.offsetTop;
    }

    ctx.clearRect(0,0,wholeWidth,wholeHeight);

    var i;
    var piece;

    for(i = 0;i < pieces.length;i++){
        piece = pieces[i];

        if(piece == _currentPiece)
            continue;

        ctx.drawImage(img, piece.sx, piece.sy, pieceWidth, pieceHeight, piece.xPos, piece.yPos, pieceWidth, pieceHeight);
        ctx.strokeRect(piece.xPos, piece.yPos, pieceWidth,pieceHeight);

        if(_currentDropPiece == null){
            if(mousePointer.x < piece.xPos || mousePointer.x > (piece.xPos + pieceWidth) || mousePointer.y < piece.yPos || mousePointer.y > (piece.yPos + pieceHeight)){}
            else{
                _currentDropPiece 	= 	piece;
                ctx.save();
                ctx.globalAlpha 	= 	.4;
                ctx.fillRect(_currentDropPiece.xPos,_currentDropPiece.yPos,pieceWidth, pieceHeight);
                ctx.restore();
            }
        }
    }

    ctx.save();
    ctx.globalAlpha = .6;
    ctx.drawImage(img, _currentPiece.sx, _currentPiece.sy, pieceWidth, pieceHeight, mousePointer.x - (pieceWidth / 2), mousePointer.y - (pieceHeight / 2), pieceWidth, pieceHeight);
    ctx.restore();
    ctx.strokeRect( mousePointer.x - (pieceWidth / 2), mousePointer.y - (pieceHeight / 2), pieceWidth,pieceHeight);
}

function pieceDropped(e){
    document.onmousemove 	= 	null;
    document.onmouseup 		= 	null;

    if(_currentDropPiece != null){
        var tmp 			= 	{xPos:_currentPiece.xPos,yPos:_currentPiece.yPos};
        _currentPiece.xPos 	= 	_currentDropPiece.xPos;
        _currentPiece.yPos 	= 	_currentDropPiece.yPos;
        _currentDropPiece.xPos 	= 	tmp.xPos;
        _currentDropPiece.yPos 	= 	tmp.yPos;
    }

    resetPuzzle();
}

function resetPuzzle(){
    ctx.clearRect(0,0,wholeWidth,wholeHeight);
    var gameWin 	= 	true;
    var i;
    var piece;
    for(i = 0;i < pieces.length;i++){
        piece 	= 	pieces[i];

        ctx.drawImage(img, piece.sx, piece.sy, pieceWidth, pieceHeight, piece.xPos, piece.yPos, pieceWidth, pieceHeight);
        ctx.strokeRect(piece.xPos, piece.yPos, pieceWidth,pieceHeight);

        if(piece.xPos != piece.sx || piece.yPos != piece.sy)
            gameWin 	= 	false;
    }

    if(gameWin){
        setTimeout(gameOver,500);
    }
}

function gameOver(){
    document.onmousedown	=	null;
    document.onmousemove	=	null;
    document.onmouseup 		= 	null;

    initPuzzle();
}

function shuffle(array) {

	var currentIndex 	= 	array.length, temporaryValue, randomIndex;
  	
  	while (0 !== currentIndex) {
    	randomIndex 	= 	Math.floor(Math.random() * currentIndex);
    	currentIndex 	-= 	1;
	    temporaryValue 	= 	array[currentIndex];
	    array[currentIndex]	= 	array[randomIndex];
	    array[randomIndex] 	= 	temporaryValue;
  	}
  	return array;
}

window.onload	=	canvasObj.init;